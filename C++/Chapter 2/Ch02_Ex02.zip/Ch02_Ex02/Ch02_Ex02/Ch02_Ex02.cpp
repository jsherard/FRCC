// Programmer:  Jeff Sherard
// June 5, 2013
// Ch2_Ex2 Program

#include <iostream>

using namespace std;

int main()
{

	// output text to screen
	cout << "CCCCCCCCC        ++               ++"			<< endl;
	cout << "CC               ++               ++"			<< endl;
	cout << "CC         ++++++++++++++   +++++++++++++++"	<< endl;
	cout << "CC         ++++++++++++++   +++++++++++++++"	<< endl;
	cout << "CC               ++               ++"			<< endl;
	cout << "CCCCCCCCC        ++               ++"			<< endl;
	cout << "							         "			<< endl;

	// pause to read screen
	system ("pause");

	return 0;
}
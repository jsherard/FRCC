// Programmer:  Jeff Sherard
// June 8, 2013
// Ch02_Ex12 Program

#include <iostream>

using namespace std;

int main()
{
	// Declare Variables
	double fuel_tank_capacity;
	double miles_per_gallon;
	double miles_car_can_be_driven;

	// Input
	cout << "Enter the fuel tank capacity in gallons: ";
	cin >> fuel_tank_capacity;
	cout << endl;
	cout << "Enter the miles per gallons: ";
	cin >> miles_per_gallon;
	cout << endl;

	// Calculate
	miles_car_can_be_driven = fuel_tank_capacity * miles_per_gallon;

	//Output:
	cout << "The number of miles the car can be driven is " << miles_car_can_be_driven << " miles.";
	cout << endl;
	cout << endl;

	system ("pause");

	return 0;
}


